#!/bin/bash

# Instala el Acceso Directo de PassWin en el Escritorio,
# y si hace falta los paquetes necesarios.               by Pasky Ribó
#========================================================================

echo ''
if [ ! -f "/bin/yad" ];then
  echo '  Se necesita instalar el paquete "Yad"'
  echo ''
  #sudo apt install yad
  sudo dpkg -i ./pak/yad*.deb && echo -e '\n *** Yad instalado ***'
  if [ "$?" -ne 0 ];then
    echo ''   
    read -p ' ¡Error!, [Intro] para salir' t
    exit 
  fi
  echo ''
  sleep 3 
fi
if [ ! -f "/sbin/chntpw" ];then
  echo '  Se necesita instalar el paquete "chntpw"'
  echo ''
  sudo dpkg -i ./pak/chntpw*.deb && echo -e '\n *** Chntpw instalado ***'
  if [ "$?" -ne 0 ];then
    echo ''
    read -p ' ¡Error!, [Intro] para salir' t
    exit 
  fi  
  #sudo apt install chntpw
  echo ''
  sleep 3
fi

error=0
# Copia Script e icono
cp -r ./.local/* ~/.local || error=1

echo '
[Desktop Entry]
Version=1.0
Type=Application
Name=PassWin
Comment=Inicia wind2 sin contraseña
Exec='$HOME'/.local/bin/PassWin_v3.4Beta.sh
Icon='$HOME'/.local/share/icons/PassWin.png
Path=
Terminal=false
StartupNotify=false' > ~/Escritorio/PassWin.desktop || error=1   # Copia iconos al escritorio y menú 

cp ~/Escritorio/PassWin.desktop ~/.local/share/applications || error=1

if [ "$error" -eq 0 ];then
  yad --title="PassWin" --image=gtk-info --width 550 --height 150 --text='\n\n\n<span weight=\"bold"\ font= "10" foreground=\"green"\ > *** Ya puedes Ejecutar "PassWin" desde el escritorio ***\n\n                Suerte! </span>' --button="gtk-ok" 2>/dev/null
else
   yad --title="PassWin" --image=dialog-error --width 550 --height 100 --text='\n\n\n<span weight=\"bold"\ font= "10" foreground=\"green"\ >       *** Ha habido algún error, al copiar los archivos *** </span>' --button="gtk-ok" 2>/dev/null 
fi
