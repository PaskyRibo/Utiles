#!/bin/bash

# Instala el Acceso Directo de PassWin en el Escritorio,
# y si hace falta los paquetes necesarios.               by Pasky Ribó
#========================================================================

xfce4-terminal -x ./Inst.sh

