#!/bin/bash

# Desinstala los archivos de PassWin              by Pasky Ribó
#================================================================

# Borra Script, icono, acceso del menú y escritorio.
cd ~/.local
for fich in ./bin/PassWin_* ./share/icons/PassWin* ./share/applications/PassWin* $HOME/Escritorio/PassWin*
do
  #echo $fich 
  if [ -f "$fich" ]; then   # Si existe el fichero, lo Borra
    rm $fich 
  fi
done

yad --title="PassWin" --image=gtk-info --width 350 --height 150 --text='\n\n\n<span weight=\"bold"\ font= "10" foreground=\"green"\ > *** Desinstalado "PassWin"  *** </span>' --button="gtk-ok" 2>/dev/null     
